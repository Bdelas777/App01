//
//  pruebaApp.swift
//  prueba
//
//  Created by Alumno on 18/09/23.
//

import SwiftUI

@main
struct pruebaApp: App {
    var body: some Scene {
        WindowGroup {
            EjemploView()
        }
    }
}
